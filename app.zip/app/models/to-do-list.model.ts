export interface ToDoList{
  id:any;
  title: string;
  description:string;
  status:string;
}
